## Vuforia Localizer Sample Image Targets

The files in this folder are the printable images that correspond to the sample 
trackable data sets that have been included with integration of Vuforia to the 
FTC SDK. See the ConceptVuforiaNavigation.java OpMode for details.
